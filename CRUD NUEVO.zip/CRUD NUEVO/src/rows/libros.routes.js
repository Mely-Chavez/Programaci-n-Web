import { Router } from "express";
import pool from "../views/database.js";

const router = Router();

router.get('/add', (req,res)=>{
    res.render('libros/add');
})

router.post('/add', async(req, res)=>{
    try{
        const {NombreLibro, Autor, Editorial, Year, NoPaginas} = req.body;
        const newLibro = {
            NombreLibro, Autor, Editorial, Year, NoPaginas
        }
        await pool.query('INSERT INTO libreria SET ?', [newLibro]);
        res.redirect('/list');
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/list', async(req, res) =>{
    try{
        const [result] = await pool.query('SELECT * FROM libreria');
        res.render('libros/list', {libros: result} )
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/edit/:id', async(req,res)=>{
    try{
        const{id}= req.params;
        const[libro] = await pool.query('SELECT * FROM libreria WHERE id = ?', [id]);
        const libroEdit = libro[0];
        res.render('libreria/edit', {libro: libroEdit});
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
})
router.post('/edit/:id', async(req, res)=>{
    try{
        const {NombreLibro, Autor, Editorial, Year, NoPaginas} = req.body;
        const {id} = req.params;
        const editLibro  = {
            NombreLibro, Autor, Editorial, Year, NoPaginas
        }
        await pool.query('UPDATE libreria SET ? WHERE id + ?', [editLibro, id] );
        res.redirect('/list');
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
})


router.get('/delete/: id', async(req, res)=>{
    try{
        const {id} = req.params;
        await pool.query('DELETE FROM libreria WHERE id=?', [id]);
        res.redirect('/list');
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
})

export default router;