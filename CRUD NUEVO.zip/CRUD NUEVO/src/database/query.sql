CREATE DATABASE Prueba01;
USE Prueba01;

CREATE TABLE libreria(
    NombreLibro VARCHAR(50) NOT NULL,
    Autor VARCHAR(50) NOT NULL,
    Editorial VARCHAR(50) NOT NULL,
    Year INT,
    NoPaginas INT
);

SELECT * FROM libreria;